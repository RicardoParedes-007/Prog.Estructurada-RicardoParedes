//
// Created by ricpa on 11/05/2025.
//

#ifndef FUNCION8_H
#define FUNCION8_H

#endif //FUNCION8_H

#include <iostream>
using namespace std;

void funcion8() {
    // Declarar variables
    float valores[10];   // Array de 10 valores máximos
    int contador = 0;    // Variable para contar cuántos números lleva el array
    char eleccion;       // Para que el usuario decida cuándo dejar de ingresar números

    cout << "**Hola usuario, este programa te permitira añadir 10 numeros diferentes y sumarlos**" << endl;

    while (contador < 10) {  // Contador debe ser menor a 10 para evitar desbordar memoria
        cout << "¿Te gustaria continuar? (s/n): ";
        cin >> eleccion;

        switch (eleccion) {
            case 'n':
            case 'N':
                cout << "Gracias por tu tiempo" << endl;
            contador = 10;  // Salir del bucle
            break;

            case 's':
            case 'S': { cout << "Dame el valor para la posicion " << contador + 1 << ": ";
                cin >> valores[contador];
                contador++;
                break;
            }
            //cout << "Dame el valor para la posicion " << contador + 1 << ": ";
            //cin >> valores[contador];
            //contador++;
            //break;

            default:
                cout << "Opcion no válida." << endl;
            break;
        }
    }

    // Mostrar lista de valores
    cout << "Lista de valores: ";
    for (int i = 0; i < contador; ++i) {
        cout << valores[i] << " ";
    }
    cout << endl;

    // Calcular y mostrar la sumatoria de todos los elementos
    float suma = 0;
    for (int i = 0; i < contador; ++i) {
        suma += valores[i];
    }
    cout << "La sumatoria de todos los elementos es: " << suma << endl;


}
