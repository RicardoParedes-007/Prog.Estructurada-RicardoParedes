//
// Created by ricpa on 11/05/2025.
//

#ifndef FUNCION11_H
#define FUNCION11_H

#endif //FUNCION11_H

#include <iostream>
using namespace std;

void secuencia(int n, int &longitud) {
    //se crea la variable secuencia que hace las operaciones que se necesitan
    while (n != 1) {
        cout << n << endl; // Imprime el número actual de la secuencia
        if (n % 2 == 0) {
            n = n / 2;
        } else {
            n = n * 3 + 1;
        }
        longitud++; // Incrementa la longitud de la secuencia
    }
    cout << "1" << endl;
    longitud++; // Cuenta el último "1" de la secuencia
}

    void funcion11() {
    int n1, n2, longitud1 = 0, longitud2 = 0;
    cout << "*Hola usuario, este programa hara dos secuencias numericas basada en el numero que le des y comparara su tamano" << endl;
    cout << "Ingresa un numero: ";
    cin >> n1;

    cout << "La secuencia generada por el numero que diste es:" << endl;
    secuencia(n1, longitud1);

    cout << "Ingresa otro numero: ";
    cin >> n2;

    cout << "La secuencia generada por el numero que diste es:" << endl;
    secuencia(n2, longitud2);

    cout << "La longitud de la primera secuencia fue: " << longitud1 << endl;
    cout << "La longitud de la segunda secuencia fue: " << longitud2 << endl;

    if (longitud1 > longitud2) {
        cout << "La primera secuencia es mayor." << endl;
    } else if (longitud1 < longitud2) {
        cout << "La segunda secuencia es mayor." << endl;
    } else {
        cout << "Ambas secuencias tienen la misma longitud." << endl;
    }
    cout << "gracias por usar el programa :)" ;
}
