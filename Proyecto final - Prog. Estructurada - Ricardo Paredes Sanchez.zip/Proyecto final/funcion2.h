//
// Created by ricpa on 11/05/2025.
//

#ifndef FUNCION2_H
#define FUNCION2_H

#endif //FUNCION2_H

#include <stdio.h>

void caracter_salida()
{

    printf("Hola, mundo!\n");
    printf("\tAqui simulamos oprimir el tabulador.\n");
    printf("Hola\b\bMundo!\n");
    printf("Este es un ejemplo de barra invertida: \\\n");
    printf("El texto entre comillas dobles es: \"Hola Mundo\"\n");
    printf("Hola Mundo\rCambio de posicion\n");
    int edad = 18;
    printf("Mi edad es: %d anios.\n", edad);
    float temperatura = 33.8;
    printf("Un grado celsius es igual a : %.2f°F.\n", temperatura);
    char nombre[] = "Ricardo";
    printf("Mi nombre es: %s.\n", nombre);
    char inicial = 'R';
    printf("Mi inicial es: %c.\n", inicial);
    int numero = 255;
    printf("El numero 255 en hexadecimal es: %x.\n", numero);
    printf("El numero 255 en octal es: %o.\n", numero);
}
