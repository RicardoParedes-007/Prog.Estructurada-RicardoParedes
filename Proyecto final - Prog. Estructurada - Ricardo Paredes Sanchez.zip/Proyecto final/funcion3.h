//
// Created by ricpa on 11/05/2025.
//

#ifndef FUNCION3_H
#define FUNCION3_H

#endif //FUNCION3_H

#include <iostream>
#include <cmath>
using namespace std;

void suma_cuadrados()
{
    unsigned int numero = 0;
    char seleccion = 0;
    cout << "Este programa suma numeros elevados al cuadrado" << endl;
    cout << "¿Te gustaria continuar? (teclea 's' para si y 'n' para no):" << endl;
    cin >> seleccion;

    switch (seleccion) {
        case 'n':
            cout << "Gracias por tu tiempo :)" << endl;
        break;

        case 's':
            cout << "Bienvenido, por favor ingresa el numero limite al que puede llegar el programa:" << endl;
        cin >> numero;

        unsigned int sum = 0;
        for (unsigned int i = 1; i <= numero; i++) {
            unsigned int cuadrado = pow(i, 2);
            cout << "El cuadrado de " << i << " es " << cuadrado << endl;
            sum += cuadrado;
        }
        cout << "La suma de todos los cuadrados hasta llegar al numero dado es " << sum << endl;
        break;



    }

    cout << "Gracias por su tiempo :)" << endl;

}

