/*NOMBRE: RICARDO PAREDES SANCHEZ
  FECHA: 11/Mayo/2025
  PROGRAMA: Proyecto final
  CENTRO UNIVERSITARIO DE LOS ALTOS / UNIVERSIDAD DE GUADALAJARA
  INGENIERIA EN COMPUTACION / SEGUNDO SEMESTRE
  PROFESOR: SERGIO FRANCO CASILLAS
  DESCRIPCION: Proyecto final
  */

#include <iostream>
#include "funcion1.h"
#include "funcion2.h"
#include "funcion3.h"
#include "funcion4.h"
#include "funcion5.h"
#include "funcion6.h"
#include "funcion7.h"
#include "funcion8.h"
#include "funcion9.h"
#include "funcion10.h"
#include "funcion11.h"
#include "funcion12.h"
#include "funcionAhorcado.h"
#include "funcionHanoi.h"


using namespace std;



int main(){

  char opcion = 0; //el valor de opcion se deja como un char para que el programa detecte letras y marque el error

  //imprimir los mensajes para el usuario
cout << "Bienvenido usuario, este es mi proyecto final, en el encontraras 14 codigos diferentes que podras ejecutar" << endl;
cout << "=================================================================== " << endl;
cout << "||que codigo quieres ejecutar? Si deseas salir del codigo oprime 0||" << endl;
  cout << "||0. Salir                                                        ||" << endl;
  cout << "||1. Imprimir datos del usuario                                   ||" << endl;
  cout << "||2. Imprimir caracteres de salida                                ||" << endl;
  cout << "||3. Hacer una suma de cuadrados                                  ||" << endl;
  cout << "||4. Hacer una sucesion de Fibonacci                              ||" << endl;
  cout << "||5. Ver los multiplos de 3 y 5 de un numero dado                 ||" << endl;
  cout << "||6. Hacer una suma de cuadrados hasta un numero dado             ||" << endl;
  cout << "||7. Hacer una suma de numeros primos hasta el numero dado        ||" << endl;
  cout << "||8. Hacer un arreglo y sumarlo                                   ||" << endl;
  cout << "||9. Hacer operaciones con matrices                               ||" << endl;
  cout << "||10. Hacer operaciones de conjuntos                              ||" << endl;
  cout << "||11. Hacer dos secuencias y compararlas                          ||" << endl;
  cout << "||12. Verificar si una palabra es palindromo                      ||" << endl;
  cout << "||13. Jugar al ahorcado                                           ||" << endl;
  cout << "||14. Jugar a las torres de Hanoi                                 ||" << endl;
  cout << "=================================================================== " << endl;
  cin >> opcion;
  //el usuario ingresa el numero del codigo que quiere ejecutar y ese valor se guarda en la variable opcion

  //inicio de switch opcion
  switch (opcion) {
    case 0: cout << "Muchisimas gracias por probar mi codigo, espero que te haya gustado y te hayas divertido" << endl;
    break;
    //del case 1 al case 14 mandamos llamar las funciones de los otros codigos
    case 1: datos_usuario();
    break;
    case 2: caracter_salida();
    break;
    case 3: suma_cuadrados();
    break;
    case 4: funcion4();
    break;
    case 5: funcion5();
    break;
    case 6: funcion6();
    break;
    case 7: funcion7();
    break;
    case 8: funcion8();
    break;
    case 9: funcion9();
    break;
    case 10: funcion10();
    break;
    case 11: funcion11();
    break;
    case 12: funcion12();
    break;
    case 13: funcionAhorcado();
    break;
    case 14: funcionHanoi();
    break;
    //en caso de que el valor este fuera del rango posible de opciones, imprimir el mensaje de error
    default: cout << "ERROR, Valor no valido" << endl;
    break;

  }//fin de switch
  return 0;
}//fin de main