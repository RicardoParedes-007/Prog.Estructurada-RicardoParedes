//
// Created by ricpa on 11/05/2025.
//

#ifndef FUNCION7_H
#define FUNCION7_H

#endif //FUNCION7_H

#include <iostream>
using namespace std;

//Desarrollo de la variable "primo"
bool primo(int numero) {  //primo es un boleano y los datos que se ingresan en primo, es la variable entera numero
    if (numero <= 1) return false;     //si el numero es negativo, 0 o 1, el boleano regresa "falso"
    for (int i = 2; i <= numero / 2; i++) {  //el bucle continuara mientras que i sea menor o igual a la mitad del numero
        if (numero% i == 0) return false;  // si el numero que da el usuario es divisible entre i, regresa "falso"
    }
    return true;   //si las condiciones del for se cumplen, primo es igual a "verdadero"
}
//inicio de main
void funcion7() {
    //se declaran las variables enteras n y suma y se inician en 0
    int n, suma = 0;
    //imprimimos los siguientes mensajes al usuario
    cout << "**Bienvenido usuario, este programa te dira los numeros primos entre el 1 y el numero que quieras**" << endl;
    cout << "**Por favor introduce un numero** ";
    //el valor que ponga el usuario se guarda en la variable n
    cin >> n;

    for (int i = 2; i <= n; i++) {  //se declara el bucle y decimos que i no puede ser mayor a n
        if (primo(i)) {   //aqui se llama a la funcion, la cual , recibe los datos que tiene i
            suma += i;    //a la variable suma se le aumenta el valor de i
            cout << i << "  ";  //imprimimos el valor de i, solo si es primo
        }
    }

    cout <<endl << "La suma de los numeros primos hasta " << n << " es: " << suma << endl;
    cout << "~~~Gracias por usar mi programa, que tengas un lindo dia~~~" << endl;

}
