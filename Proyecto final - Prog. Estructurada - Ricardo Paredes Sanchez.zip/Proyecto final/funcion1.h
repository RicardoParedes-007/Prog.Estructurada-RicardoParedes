

#ifndef FUNCION1_H
#define FUNCION1_H

#endif //FUNCION1_H

#include <stdio.h>

void datos_usuario() {

    printf("Nombre: Ricardo Paredes Sanchez\n");
    printf("Edad: 18 anios\n");
    printf("Lugar de residencia: Capilla de Guadalupe\n");
    printf("Fecha: 30 de Enero del 2025\n");
    printf("Carrera: Ingenieria en Computacion\n");
    printf("Semestre: Segundo Semestre\n");
}
